These are the ALGs that were released in Schultz et al. 2023.

Updates include:
- 20230512 - fixed some errors with the hex color codes on ALG_K
- 202304 - Initial Upload